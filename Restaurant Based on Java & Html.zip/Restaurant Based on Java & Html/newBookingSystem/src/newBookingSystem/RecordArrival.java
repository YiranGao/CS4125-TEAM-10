package newBookingSystem;

import java.awt.BorderLayout;
import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JPanel;
import com.borland.jbcl.layout.XYLayout;
import com.borland.jbcl.layout.*;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.*;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class RecordArrival extends JDialog {
    JPanel panel1 = new JPanel();
    XYLayout xYLayout1 = new XYLayout();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JTextField ControlTno = new JTextField();
    JTextField ControlDate = new JTextField();
    JButton jButton1 = new JButton();
    JButton jButton2 = new JButton();
    XYLayout xYLayout2 = new XYLayout();

    /////////////////////�û������ȷ������ȡ���ı��ֵ//////////////////////////////////
 ////////////////////////////////////////////////////////////////////////
   public static boolean isConfirm;

   ///////////////////////�Ի����б���////////////////////////////////////
   /////////////////////////////////////////////////////////////////////
   private int tno;
   private String strDate;


    public RecordArrival(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    ///////////////////////////����������//////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////

    public void enableControlTno(boolean tf)
    {
        ControlTno.setEditable(tf);

    }
    public void SetControlTno(int tno)
      {
          ControlTno.setText(Integer.toString(tno));

      }


    public int getTno()
        {
            return tno;
        }
        public String getStrDate()
        {
            return strDate;
        }
    public RecordArrival() {
        this(new Frame(), "RecordArrival", false);
    }
    //////////////////////�����������ʼֵ/////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    public void SetControlDate(String strDate)
   {
       ControlDate.setText(strDate);
   }


    private void jbInit() throws Exception {
        panel1.setLayout(xYLayout1);
       // ControlTno.setDocument(new NumberLenghtLimitedDmt(2));
        this.setModal(true);
        this.setTitle("��¼����") ;
        this.getContentPane().setLayout(xYLayout2);
        jLabel1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setText("����:");
        jLabel2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel2.setText("����:");
        jButton1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton1.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton1.setText("ȷ��");
        jButton1.addActionListener(new RecordArrival_jButton1_actionAdapter(this));
        jButton2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton2.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton2.setText("ȡ��");
        jButton2.addActionListener(new RecordArrival_jButton2_actionAdapter(this));
        ControlDate.setEnabled(false);
        ControlDate.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlDate.setHorizontalAlignment(SwingConstants.CENTER);
        xYLayout2.setWidth(282);
        xYLayout2.setHeight(185);
        ControlTno.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTno.setHorizontalAlignment(SwingConstants.CENTER);
        panel1.add(jLabel2, new XYConstraints(26, 17, 68, 39));
        panel1.add(ControlDate, new XYConstraints(111, 18, 118, 33));
        panel1.add(jButton2, new XYConstraints(148, 72, -1, 37));
        panel1.add(jButton1, new XYConstraints(37, 73, 76, 37));
        this.getContentPane().add(jLabel1, new XYConstraints(27, 18, 68, 39));
        this.getContentPane().add(ControlTno,
                                  new XYConstraints(112, 20, 118, 33));
        this.getContentPane().add(panel1, new XYConstraints(0, 57, 294, -1));
    }
/////////////////////////////////�Ի����ϵ�ȷ����ť��Ӧ�¼�//////////////////////////
    /////////////////////////////////////////////////////////////////////////////
    public void jButton1_actionPerformed(ActionEvent e) {
        isConfirm = true;
      String strTno = ControlTno.getText().trim();
      tno = Integer.parseInt(strTno);
      strDate = ControlDate.getText().trim();
     this.dispose();
    }
///////////////////////////////////�Ի�����ȡ����ť����Ӧ�¼�//////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    public void jButton2_actionPerformed(ActionEvent e) {
         isConfirm = false;
         this.dispose();

    }
}
class RecordArrival_jButton2_actionAdapter implements ActionListener {
    private RecordArrival adaptee;
    RecordArrival_jButton2_actionAdapter(RecordArrival adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton2_actionPerformed(e);
    }
}
class RecordArrival_jButton1_actionAdapter implements ActionListener {
    private RecordArrival adaptee;
    RecordArrival_jButton1_actionAdapter(RecordArrival adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton1_actionPerformed(e);
    }
}
