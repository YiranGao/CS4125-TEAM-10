package newBookingSystem;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2007</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
//this class is to connect database ;
import java.sql.*;
import javax.swing.JOptionPane;

public class ConnectDataBase {

  //define driver which to connect database
  private String driver;

  //define class of connecttion
  private Connection conn;

  //define address of database of SQL Server
  private String url;
  private String query;

  //Statement statement ;
  PreparedStatement preparedStatement ;
  //delare ResultSet
  ResultSet resultSet;
   public void  setQuery(String sql)
   {
     query = sql;
   }

   public String getQuery()
   {
     return query;
   }


  public void connect() {
    driver = "com.microsoft.jdbc.sqlserver.SQLServerDriver";

    //define address of database of SQL Server
     url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=" +
        "BookingSystem;User =sa;Password = leejoon";
     conn = null;

    try {
      Class.forName(driver);

      conn = DriverManager.getConnection(url, "sa", "leejoon");

      //����һ�� PreparedStatement ���������������� SQL ��䷢�͵����ݿ�
           // preparedStatement = getConnection().prepareStatement(getQuery());

      if (conn != null) {
        //�����õ����
        System.out.println("sucess to connect database !");
        System.out.println("conn.getCatalog() = " + conn.getCatalog());
      }
    }
    catch (Exception ex) {
      //JOptionPane.showMessageDialog(null,"�������ݿ����!","����",JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }

  }

  public void preparedStatement()
  {
    try
    {
      //����һ�� PreparedStatement ���������������� SQL ��䷢�͵����ݿ�
       preparedStatement = getConnection().prepareStatement(getQuery());

    /*  if (conn != null) {
        //�����õ����
        System.out.println("sucess to connect database !");
        System.out.println("conn.getCatalog() = " + conn.getCatalog());
      }
    */
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }


  }
  //ִ�в�ѯ��SQL ��䡣
  public ResultSet  executeQuery()
  {
    try
    {
      resultSet  =  preparedStatement.executeQuery() ;
     }
    catch (Exception ex) {
     ex.printStackTrace();
   }
   return resultSet;

  }

  public void executeUpdate()
  {
    try
    {
       preparedStatement.executeUpdate() ;

     }
    catch (Exception ex) {
     ex.printStackTrace();
   }


  }

  public PreparedStatement getPreparedStatement ()
  {
    return preparedStatement ;
  }
 public Connection getConnection()
  {
    return conn;
  }

  void closeConnect() {
    try {
      if(!conn.isClosed() )
           conn.close();
    }
    catch (Exception ex) {
      //JOptionPane.showMessageDialog(null,"�������ݿⷢ������!","����",JOptionPane.ERROR_MESSAGE);
      ex.printStackTrace();
    }

  }
}
