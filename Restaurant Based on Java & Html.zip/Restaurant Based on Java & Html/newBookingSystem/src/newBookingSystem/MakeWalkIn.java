package newBookingSystem;

import java.awt.BorderLayout;
import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JPanel;
import com.borland.jbcl.layout.XYLayout;
import com.borland.jbcl.layout.*;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.Color;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class MakeWalkIn extends JDialog {
    JPanel panel1 = new JPanel();
    XYLayout xYLayout1 = new XYLayout();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JTextField ControlTno = new JTextField();
    JTextField ControlDate = new JTextField();
    JButton jButton1 = new JButton();
    JButton jButton2 = new JButton();

    /////////////////////�û������ȷ������ȡ���ı��ֵ//////////////////////////////////
  ////////////////////////////////////////////////////////////////////////
    public static boolean isConfirm;

    ///////////////////////�Ի����б���////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    private int tno;
    private String strDate;


    public MakeWalkIn(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    public int getTno()
      {
          return tno;
      }
      public String getStrDate()
      {
          return strDate;
   }


    public MakeWalkIn() {
        this(new Frame(), "MakeWalkIn", false);
    }
    ///////////////////////////���������� ��ʼֵ//////////////////////////////////
       ////////////////////////////////////////////////////////////////////////////
       public void SetControlDate(String strDate)
       {
           ControlDate.setText(strDate);
       }
       ///////////////////////////��ʼ������//////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////////////
   public void enableControlTno(boolean tf)
     {
         ControlTno.setEditable(tf);

    }
   public void SetControlTno(int tno)
   {
       ControlTno.setText(Integer.toString(tno));

   }


    private void jbInit() throws Exception {
        this.setModal(true);
        this.setTitle("�û�ֱ�ӵ���");
        //ControlTno.setDocument(new NumberLenghtLimitedDmt(2));
        panel1.setLayout(xYLayout1);
        jLabel1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel1.setText("����:");
        jLabel2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel2.setText("����:");
        ControlTno.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTno.setToolTipText("");
        ControlTno.setHorizontalAlignment(SwingConstants.CENTER);
        ControlDate.setEnabled(false);
        ControlDate.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlDate.setHorizontalAlignment(SwingConstants.CENTER);
        jButton1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton1.setText("ȷ��");
        jButton1.addActionListener(new MakeWalkIn_jButton1_actionAdapter(this));
        jButton2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton2.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton2.setText("ȡ��");
        jButton2.addActionListener(new MakeWalkIn_jButton2_actionAdapter(this));
        this.getContentPane().add(panel1, java.awt.BorderLayout.CENTER);
        panel1.add(jLabel1, new XYConstraints(28, 24, 85, 35));
        panel1.add(jLabel2, new XYConstraints(28, 69, 85, 35));
        panel1.add(jButton2, new XYConstraints(199, 117, 76, 35));
        panel1.add(jButton1, new XYConstraints(82, 116, 76, 35));
        panel1.add(ControlDate, new XYConstraints(125, 70, 159, -1));
        panel1.add(ControlTno, new XYConstraints(125, 26, 159, -1));
    }
//////////////////////////�Ի���ȷ����ť��Ӧ����////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    public void jButton1_actionPerformed(ActionEvent e) {
        isConfirm = true;
       String strTno = ControlTno.getText().trim();
       tno = Integer.parseInt(strTno);
       strDate = ControlDate.getText().trim();
      this.dispose();
    }
    /////////////////////�Ի���ȡ����ť��Ӧ����////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    public void jButton2_actionPerformed(ActionEvent e) {
        isConfirm = false;
        this.dispose();
    }
}


class MakeWalkIn_jButton1_actionAdapter implements ActionListener {
    private MakeWalkIn adaptee;
    MakeWalkIn_jButton1_actionAdapter(MakeWalkIn adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton1_actionPerformed(e);
    }
}


class MakeWalkIn_jButton2_actionAdapter implements ActionListener {
    private MakeWalkIn adaptee;
    MakeWalkIn_jButton2_actionAdapter(MakeWalkIn adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton2_actionPerformed(e);
    }
}
