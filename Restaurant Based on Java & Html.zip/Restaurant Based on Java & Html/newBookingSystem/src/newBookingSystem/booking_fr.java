package newBookingSystem;


import java.util.Calendar;
import java.util.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.datatransfer.*;
import java.io.*;
import java.awt.dnd.*;
import java.text.SimpleDateFormat;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.XYLayout;
import com.borland.jbcl.layout.*;
import java.awt.Color;
import javax.swing.BorderFactory;
import java.awt.SystemColor;
import javax.swing.Box;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.util.Observer;
import java.util.Observable;
import java.awt.Font;
import com.sunking.swing.JCalendarPanel;
import com.sunking.swing.JDatePicker;
import java.text.*;
import com.sunking.swing.JStatusBar;
import java.util.Vector;




public class booking_fr extends JFrame implements Observer{
    int everEnterFlag ;
    //////////////////////����Ƿ�ǰΪ��ק״̬////////////////////
    int dragFlag;
    BookingSystem bookingSystem;
    /////////////////////////////����Table��Text��Ϣ///////////////
    String tempTabelText;
    ////////////////////////////��ʾ�Ҽ��Ƿ�����������//////////////
    int tip;
    //////////////////////////�����û����������//////////////////////
    int tempTno;
    ///////////////////////�������ӵ�JLabel����/////////////////////
    /////////////////////��ʱ���汻��ק���ӵ�Text��Ϣ///////////////////
    String tempDragFromText;
    /////////////////////��ʱ������ק�����ӵ�Text��Ϣ//////////////////
    String tempDragToText;
    Vector vector = new Vector(16);
    JPanel contentPane;
    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu jMenuFile = new JMenu();
    JMenuItem jMenuFileExit = new JMenuItem();
    XYLayout xYLayout1 = new XYLayout();
    PopupMenu popupMenu1 = new PopupMenu();
    MenuItem menuItem1 = new MenuItem("����ԤԼ");
    MenuItem menuItem2 = new MenuItem("ԤԼ����");
    MenuItem menuItem3 = new MenuItem("ȡ��ԤԼ");
    MenuItem menuItem4 = new MenuItem("��������");
    MenuItem menuItem5 = new MenuItem("δԼ�ò�");
////////////////////////////////������������Label/////////////////////////
    //////////////////////////////////////////////////////////////////////
    JLabel table1 = new JLabel();
    JLabel table2 = new JLabel();
    JLabel table3 = new JLabel();
    JLabel table4 = new JLabel();
    JLabel table5 = new JLabel();
    JLabel table6 = new JLabel();
    JLabel table7 = new JLabel();
    JLabel table8 = new JLabel();

/////////////////////////////////////������������Label///////////////////////////
    //////////////////////////////////////////////////////////////////////////
    JLabel table9 = new JLabel();
    JLabel table10 = new JLabel();
    JLabel table11 = new JLabel();
    JLabel table12 = new JLabel();
    JLabel table13 = new JLabel();
    JLabel table14 = new JLabel();
    JLabel table15 = new JLabel();
    JLabel table16 = new JLabel();

    JButton jButton1 = new JButton();
    JButton jButton2 = new JButton();
    JButton jButton3 = new JButton();
    JButton jButton4 = new JButton();
    JButton jButton5 = new JButton();
    JButton jButton6 = new JButton();
    JButton jButton7 = new JButton();
    ///////////////////////////���ڿؼ�����//////////////////////////////////
    /////////////////////////////////////////////////////////////////////////
    JDatePicker date1 = new JDatePicker();
    JButton jButton8 = new JButton();
    //////////////////////�۲��߹��캯�����������뵽�۲��߼���///////////////////
    ///////////////////////////////////////////////////////////////////////////
    public booking_fr(BookingSystem bs) {
        try {
            bs.addObserver(this);

            bookingSystem = bs;



           // displayBooking(this.getCalendarDate());
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            jbInit();
            bookingSystem.Display(this.getCalendarDate());
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    /**
     * Component initialization.
     *
     * @throws java.lang.Exception
     */
    private void jbInit() throws Exception {
        contentPane = (JPanel) getContentPane();
        contentPane.setLayout(xYLayout1);
        setSize(new Dimension(645, 437));
        setTitle("Frame Title");
        this.addMouseListener(new booking_fr_this_mouseAdapter(this));
        jMenuFile.setText("File");
        jMenuFileExit.addActionListener(new
                                        booking_fr_jMenuFileExit_ActionAdapter(this));
        table6.setBackground(Color.white);
        table6.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table6.setBorder(BorderFactory.createLineBorder(Color.black));
        table6.setOpaque(true);
        table6.setPreferredSize(new Dimension(200, 100));
        table6.setHorizontalAlignment(SwingConstants.CENTER);
        table6.setHorizontalTextPosition(SwingConstants.CENTER);
        table6.setText("(6)������");
        table6.addMouseMotionListener(new booking_fr_table6_mouseMotionAdapter(this));
        table6.addMouseListener(new booking_fr_table5_mouseAdapter(this));
        contentPane.setBackground(new Color(166, 202, 240));
        contentPane.setBorder(BorderFactory.createLineBorder(Color.black));
        contentPane.addInputMethodListener(new
                booking_fr_contentPane_inputMethodAdapter(this));
        contentPane.addMouseListener(new booking_fr_contentPane_mouseAdapter(this));
        contentPane.addMouseMotionListener(new
                booking_fr_contentPane_mouseMotionAdapter(this));
        table3.setBackground(Color.white);
        //table3.setBackground(Color.blue) ;
        table3.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table3.setBorder(BorderFactory.createLineBorder(Color.black));
        //Color color = new Color() ;
        table3.setOpaque(true);
        table3.setPreferredSize(new Dimension(200, 100));
        table3.setToolTipText("");
        table3.setHorizontalAlignment(SwingConstants.CENTER);
        table3.setHorizontalTextPosition(SwingConstants.CENTER);
        table3.setText("(3)������");
        table3.addMouseMotionListener(new booking_fr_table3_mouseMotionAdapter(this));
        table3.addMouseListener(new booking_fr_table3_mouseAdapter(this));
        table2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table2.setBorder(BorderFactory.createLineBorder(Color.black));
        table2.setOpaque(true);
        table2.setPreferredSize(new Dimension(200, 100));
        table2.setHorizontalAlignment(SwingConstants.CENTER);
        table2.setHorizontalTextPosition(SwingConstants.CENTER);
        table2.setText("(2)������");
        table2.addMouseMotionListener(new booking_fr_table2_mouseMotionAdapter(this));
        table2.addMouseListener(new booking_fr_table2_mouseAdapter(this));
        table5.setBackground(Color.white);
        table5.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table5.setBorder(BorderFactory.createLineBorder(Color.black));
        table5.setOpaque(true);
        table5.setPreferredSize(new Dimension(200, 100));
        table5.setHorizontalAlignment(SwingConstants.CENTER);
        table5.setHorizontalTextPosition(SwingConstants.CENTER);
        table5.setText("(5)������");
        table5.addMouseMotionListener(new booking_fr_table5_mouseMotionAdapter(this));
        table5.addMouseListener(new booking_fr_table4_mouseAdapter(this));
        table4.setBackground(Color.white);
        table4.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table4.setBorder(BorderFactory.createLineBorder(Color.black));
        table4.setOpaque(true);
        table4.setPreferredSize(new Dimension(200, 100));
        table4.setHorizontalAlignment(SwingConstants.CENTER);
        table4.setHorizontalTextPosition(SwingConstants.CENTER);
        table4.setText("(4)������");
        table4.addMouseMotionListener(new booking_fr_table4_mouseMotionAdapter(this));
        table4.addMouseListener(new booking_fr_table6_mouseAdapter(this));
        table9.setBackground(Color.white);
        table9.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table9.setBorder(BorderFactory.createLineBorder(Color.black));
        table9.setOpaque(true);
        table9.setPreferredSize(new Dimension(200, 100));
        table9.setHorizontalAlignment(SwingConstants.CENTER);
        table9.setHorizontalTextPosition(SwingConstants.CENTER);
        table9.setText("(9)������");
        table9.addMouseListener(new booking_fr_table9_mouseAdapter(this));
        table9.addKeyListener(new booking_fr_table9_keyAdapter(this));
        table9.addMouseMotionListener(new booking_fr_table9_mouseMotionAdapter(this));
        table8.setBackground(Color.white);
        table8.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table8.setBorder(BorderFactory.createLineBorder(Color.black));
        table8.setOpaque(true);
        table8.setPreferredSize(new Dimension(200, 100));
        table8.setHorizontalAlignment(SwingConstants.CENTER);
        table8.setHorizontalTextPosition(SwingConstants.CENTER);
        table8.setText("(8)������");
        table8.addMouseMotionListener(new booking_fr_table8_mouseMotionAdapter(this));
        table8.addMouseListener(new booking_fr_table8_mouseAdapter(this));
        table7.setBackground(Color.white);
        table7.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table7.setBorder(BorderFactory.createLineBorder(Color.black));
        table7.setOpaque(true);
        table7.setPreferredSize(new Dimension(200, 100));
        table7.setHorizontalAlignment(SwingConstants.CENTER);
        table7.setHorizontalTextPosition(SwingConstants.CENTER);
        table7.setText("(7)������");
        table7.addMouseMotionListener(new booking_fr_table7_mouseMotionAdapter(this));
        table7.addMouseListener(new booking_fr_table9_mouseAdapter(this));
        table1.setBackground(Color.white);
        table1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table1.setBorder(BorderFactory.createLineBorder(Color.black));
        table1.setOpaque(true);
        table1.setPreferredSize(new Dimension(200, 100));
        table1.setToolTipText("�����������Ϊ���� ");
        table1.setHorizontalAlignment(SwingConstants.CENTER);
        table1.setText("(1)������");
        table1.addMouseMotionListener(new booking_fr_table1_mouseMotionAdapter(this));
        table1.addMouseListener(new booking_fr_jLabel9_mouseAdapter(this));
        table10.setBackground(Color.white);
        table10.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table10.setForeground(Color.black);
        table10.setBorder(BorderFactory.createLineBorder(Color.black));
        table10.setOpaque(true);
        table10.setPreferredSize(new Dimension(200, 100));
        table10.setHorizontalAlignment(SwingConstants.CENTER);
        table10.setHorizontalTextPosition(SwingConstants.CENTER);
        table10.setText("(10)������");
        table10.addMouseListener(new booking_fr_table10_mouseAdapter(this));
        table10.addMouseMotionListener(new
                                       booking_fr_table10_mouseMotionAdapter(this));
        table11.setBackground(Color.white);
        table11.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table11.setBorder(BorderFactory.createLineBorder(Color.black));
        table11.setOpaque(true);
        table11.setPreferredSize(new Dimension(200, 100));
        table11.setHorizontalAlignment(SwingConstants.CENTER);
        table11.setHorizontalTextPosition(SwingConstants.CENTER);
        table11.setText("(11)������");
        table11.addMouseListener(new booking_fr_table11_mouseAdapter(this));
        table11.addMouseMotionListener(new
                                       booking_fr_table11_mouseMotionAdapter(this));
        table12.setBackground(Color.white);
        table12.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table12.setBorder(BorderFactory.createLineBorder(Color.black));
        table12.setOpaque(true);
        table12.setPreferredSize(new Dimension(200, 100));
        table12.setHorizontalAlignment(SwingConstants.CENTER);
        table12.setHorizontalTextPosition(SwingConstants.CENTER);
        table12.setText("(12)������");
        table12.addMouseListener(new booking_fr_table12_mouseAdapter(this));
        table12.addMouseMotionListener(new
                                       booking_fr_table12_mouseMotionAdapter(this));
        table13.setBackground(Color.white);
        table13.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table13.setBorder(BorderFactory.createLineBorder(Color.black));
        table13.setOpaque(true);
        table13.setPreferredSize(new Dimension(200, 100));
        table13.setHorizontalAlignment(SwingConstants.CENTER);
        table13.setHorizontalTextPosition(SwingConstants.CENTER);
        table13.setText("(13)������");
        table13.addMouseListener(new booking_fr_table13_mouseAdapter(this));
        table13.addMouseMotionListener(new
                                       booking_fr_table13_mouseMotionAdapter(this));
        table14.setBackground(Color.white);
        table14.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table14.setBorder(BorderFactory.createLineBorder(Color.black));
        table14.setOpaque(true);
        table14.setPreferredSize(new Dimension(200, 100));
        table14.setHorizontalAlignment(SwingConstants.CENTER);
        table14.setHorizontalTextPosition(SwingConstants.CENTER);
        table14.setText("(14)������");
        table14.addMouseListener(new booking_fr_table14_mouseAdapter(this));
        table14.addMouseMotionListener(new
                                       booking_fr_table14_mouseMotionAdapter(this));
        table15.setBackground(Color.white);
        table15.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table15.setBorder(BorderFactory.createLineBorder(Color.black));
        table15.setOpaque(true);
        table15.setPreferredSize(new Dimension(200, 100));
        table15.setHorizontalAlignment(SwingConstants.CENTER);
        table15.setHorizontalTextPosition(SwingConstants.CENTER);
        table15.setText("(15)������");
        table15.addMouseListener(new booking_fr_table15_mouseAdapter(this));
        table15.addMouseMotionListener(new
                                       booking_fr_table15_mouseMotionAdapter(this));
        table16.setBackground(Color.white);
        table16.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        table16.setBorder(BorderFactory.createLineBorder(Color.black));
        table16.setOpaque(true);
        table16.setPreferredSize(new Dimension(200, 100));
        table16.setHorizontalAlignment(SwingConstants.CENTER);
        table16.setHorizontalTextPosition(SwingConstants.CENTER);
        table16.setText("(16)������");
        table16.addMouseListener(new booking_fr_table16_mouseAdapter(this));
        table16.addMouseMotionListener(new
                                       booking_fr_table16_mouseMotionAdapter(this));
        jButton1.setEnabled(false);
        jButton1.setText("jButton1");
        jButton2.setEnabled(false);
        jButton2.setText("jButton1");
        jButton3.setEnabled(false);
        jButton3.setText("jButton1");
        jButton4.setBackground(Color.white);
        jButton4.setEnabled(false);
        jButton4.setText("jButton4");
        jButton5.setEnabled(false);
        jButton5.setText("jButton5");
        jButton6.setEnabled(false);
        jButton6.setText("jButton6");
        jButton7.setEnabled(false);
        jButton7.setText("jButton7");
        date1.setBackground(Color.green);
        date1.setBorder(BorderFactory.createLineBorder(Color.black));
        date1.addPopupMenuListener(new booking_fr_date1_popupMenuAdapter(this));
        date1.addMouseListener(new booking_fr_date1_mouseAdapter(this));
        popupMenu1.addActionListener(new booking_fr_popupMenu1_actionAdapter(this));
        jButton8.setFont(new java.awt.Font("����", Font.BOLD, 14));
        jButton8.setBorder(BorderFactory.createLineBorder(Color.black));
        jButton8.setText("��ʾ");
        jButton8.addActionListener(new booking_fr_jButton8_actionAdapter(this));
        popupMenu1.add(menuItem1);
        popupMenu1.add(menuItem2);
        popupMenu1.add(menuItem3);
        popupMenu1.add(menuItem4);
        popupMenu1.add(menuItem5);
////////////////////������JLabel�������ӱ���/////////////////////////////////////
        vector.add(table1);
        vector.add(table2);
        vector.add(table3);
        vector.add(table4);
        vector.add(table5);
        vector.add(table6);
        vector.add(table7);
        vector.add(table8);
        vector.add(table9);
        vector.add(table10);
        vector.add(table11);
        vector.add(table12);
        vector.add(table13);
        vector.add(table14);
        vector.add(table15);
        vector.add(table16);
//��this�м���popupMenu1
        add(popupMenu1);

        menuItem1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
        menuItem1_actionPerformed(e);
}
});
       menuItem2.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(ActionEvent e) {
       menuItem2_actionPerformed(e);
}
});
       menuItem3.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(ActionEvent e) {
       menuItem3_actionPerformed(e);
}
});
       menuItem4.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(ActionEvent e) {
       menuItem4_actionPerformed(e);
}
});
       menuItem5.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(ActionEvent e) {
       menuItem5_actionPerformed(e);
}
});


        jMenuBar1.add(jMenuFile);
        jMenuFile.add(jMenuFileExit);
        contentPane.add(jButton6, new XYConstraints(482, 30, 2, 363));
        contentPane.add(jButton1, new XYConstraints( -2, 108, 644, 1));
        contentPane.add(jButton2, new XYConstraints( -6, 203, 650, 1));
        contentPane.add(jButton3, new XYConstraints( -2, 303, 645, 2));
        contentPane.add(jButton4, new XYConstraints(165, 30, 2, 361));
        contentPane.add(table2, new XYConstraints(194, 39, 105, 55));
        contentPane.add(table10, new XYConstraints(194, 220, 105, 55));
        contentPane.add(table1, new XYConstraints(45, 39, 105, 55));
        contentPane.add(table3, new XYConstraints(357, 39, 105, 55));
        contentPane.add(table4, new XYConstraints(498, 38, 105, 55));
        contentPane.add(table8, new XYConstraints(500, 122, 105, 55));
        contentPane.add(table7, new XYConstraints(357, 122, 105, 55));
        contentPane.add(table6, new XYConstraints(194, 122, 105, 55));
        contentPane.add(table5, new XYConstraints(45, 122, 105, 55));
        contentPane.add(table9, new XYConstraints(45, 220, 105, 55));
        contentPane.add(table13, new XYConstraints(45, 319, 105, 55));
        contentPane.add(table14, new XYConstraints(194, 319, 105, 55));
        contentPane.add(table11, new XYConstraints(357, 220, 105, 55));
        contentPane.add(table15, new XYConstraints(357, 319, 105, 55));
        contentPane.add(table16, new XYConstraints(500, 319, 105, 55));
        contentPane.add(table12, new XYConstraints(500, 220, 105, 55));
        contentPane.add(jButton7, new XYConstraints(2, 29, 638, 3));
        contentPane.add(jButton5, new XYConstraints(323, 29, 3, 358));
        contentPane.add(date1, new XYConstraints(5, 1, -1, 24));
        contentPane.add(jButton8, new XYConstraints(100, 1, 64, 28));
        setJMenuBar(jMenuBar1);
    }

    /**
     * File | Exit action performed.
     *
     * @param actionEvent ActionEvent
     */
    void jMenuFileExit_actionPerformed(ActionEvent actionEvent) {
        System.exit(0);
    }
    /////////////////////��ȡ��ǰ����ǰһ��/////////////////////////////////////
  /////////////////////////////////////////////////////////////////////////
  public Date currentDateSubOne()
  {
      Date   currentDay   =   new   Date();
      Calendar   cal   =  Calendar.getInstance();
      cal.setTime(currentDay) ;
      cal.add(cal.DAY_OF_MONTH ,-1);
      Date   daySubOne   =   cal.getTime() ;
      return daySubOne;
  }
  //////////////////////////////���ںϷ����ж�/////////////////////////////
  ///////////////////////////////////////////////////////////////////////
  public boolean dateJudge(Date date)
  {
      if(this.getCalendarDate().before(date))
     {
         JOptionPane.showConfirmDialog(null,"��ѡ����һ����ȥ�����ڣ�����ʧ�ܣ�","ѡ��",-1);
         return false;
     }
     else
         return true;
  }
  ////////////////////////�������ŵõ���ӦJLabel����//////////////////////////
   /////////////////////////////////////////////////////////////////////////
   public JLabel getTableObjByTno(int tno)
   {
       return (JLabel)(vector.get(tno-1));
   }
   //////////////////////��������Text��Ϣ�õ�����//////////////////////////////
   ////////////////////////////////////////////////////////////////////////
   public int getTableTnoByText(String tableText)
   {
       int i = 0;
       for( i=0;i<vector.size();i++)
       {
           if(((JLabel)vector.get(i)).getText().trim()==tableText)
           {
               break;
           }
       }
       return i+1;
   }
 ///////////////////////////////��Ӧ�Ҽ���һ���˵���////////////////////////
    /////////////////////////////////////////////////////////////////////////
    void menuItem1_actionPerformed(ActionEvent e)
    {
        if(dateJudge(this.currentDateSubOne())==false)
       {
           return;
       }

        AddReservation dlg = new AddReservation() ;
        dlg.setLocation(400,300) ;
        dlg.SetControlDate(getStrCalendarDate());
        if(tip==1)
        {
            dlg.SetControlTno(tempTno);
            dlg.enableControlTno(false);
            if((this.getTableObjByTno(tempTno)).getBackground()==Color.green )
         {
             JOptionPane.showConfirmDialog(null,"����ѡ���ʱ�䵱ǰѡ������Ѿ�ԤԼ������ִ��ԤԼ��","ԤԼʧ�ܣ�",-1);
             return;
         }
         if((this.getTableObjByTno(tempTno)).getBackground()==Color.red )
         {
             JOptionPane.showConfirmDialog(null,"����ѡ���ʱ�䵱ǰ�����Ѿ����˾Ͳͣ�����ִ��ԤԼ��","ԤԼʧ�ܣ�",-1);
             return;
         }

            tip = 0;
        }
        dlg.show();
        if(dlg.isConfirm == false)
        {
            return;
        }
        else
        {
            this.makeReservation(this.getCalendarDate(),dlg.getTno(),dlg.getStrName(),dlg.GetTel()) ;
            return;
        }


    }
    ////////////////////////////////��Ӧ�Ҽ��ڶ����˵���////////////////////////
    /////////////////////////////////////////////////////////////////////////
    void menuItem2_actionPerformed(ActionEvent e)
    {
        if(dateJudge(this.currentDateSubOne())==false)
       {
           return;
       }

        RecordArrival dlg = new RecordArrival() ;
        dlg.setLocation(400,300);
        dlg.SetControlDate(getStrCalendarDate());
        if(tip==1)
        {
            dlg.SetControlTno(tempTno);
            dlg.enableControlTno(false);
            if((this.getTableObjByTno(tempTno)).getBackground()==Color.yellow  )
       {
           JOptionPane.showConfirmDialog(null,"����ѡ���ʱ�䵱ǰѡ�������û��ԤԼ��������ԤԼ���","ԤԼ����ִ��ʧ�ܣ�",-1);
           return;
       }
       if((this.getTableObjByTno(tempTno)).getBackground()==Color.red )
       {
           JOptionPane.showConfirmDialog(null,"����ѡ���ʱ�䵱ǰ�����Ѿ����˾Ͳͣ�ԤԼ�����ܵ��","ԤԼ����ִ��ʧ�ܣ�",-1);
           return;
       }

            tip = 0;
        }
        dlg.show();
        if(dlg.isConfirm == false)
        {
            return;
        }
        else
        {
              recoreArrival(this.getCalendarDate(),tempTno);
            return;
        }
    }
    ////////////////////////////////��Ӧ�Ҽ��������˵���////////////////////////
    /////////////////////////////////////////////////////////////////////////
    void menuItem3_actionPerformed(ActionEvent e)
    {
        if(dateJudge(this.currentDateSubOne())==false)
       {
           return;
       }
        Cancel dlg = new Cancel() ;
        dlg.setLocation(400,300);
        dlg.SetControlDate(getStrCalendarDate());
        if(tip==1)
       {
           dlg.SetControlTno(tempTno);
           dlg.enableControlTno(false);
           if((this.getTableObjByTno(tempTno)).getBackground()==Color.red)
          {
              JOptionPane.showConfirmDialog(null,"��ѡ��ʱ��Ĳ��������òͣ�","ȡ��ԤԼʧ�ܣ�",-1);
              return;
          }
          if((this.getTableObjByTno(tempTno)).getBackground()== Color.yellow )
          {
              JOptionPane.showConfirmDialog(null,"��ѡ��ʱ��ĵ�ǰ������û�б�ԤԼ��","ȡ��ԤԼʧ�ܣ�",-1);
              return;
          }
          tip = 0;
     }
     dlg.show();
     if(dlg.isConfirm == false)
     {
         return;
      }
     else
     {

         this.Cancel(this.getCalendarDate(),dlg.getTno());
         return;
      }
  }


    ////////////////////////////////��Ӧ�Ҽ����ĸ��˵���////////////////////////
    /////////////////////////////////////////////////////////////////////////
    void menuItem4_actionPerformed(ActionEvent e)
    {
        if(dateJudge(this.currentDateSubOne())==false)
        {
            return;
        }
        TableChange dlg = new TableChange();
        dlg.setLocation(400,300);
        dlg.SetControlDate(getStrCalendarDate());
        if(tip==1)
       {
          dlg.SetControlTno(tempTno);
          dlg.enableControlTno(false);
          if((this.getTableObjByTno(tempTno)).getBackground()==Color.yellow  )
         {
             //JOptionPane.showConfirmDialog(null,"����ָ���Ĳ�����û��ԤԼ������ִ�в���������","��������ʧ�ܣ�",-1);
             return;
         }
         if((this.getTableObjByTno(tempTno)).getBackground()==Color.red )
         {
             //JOptionPane.showConfirmDialog(null,"����ָ���Ĳ����Ѿ����˾Ͳͣ�����ִ�в���������","��������ʧ�ܣ�",-1);
             return;
         }
          tip = 0;
      }
      dlg.show();
      if(dlg.isConfirm == false)
      {
          return;
      }
      else
      {
          transferTable(this.getCalendarDate(),dlg.getTno(),dlg.getTnoChange());
          return;
      }
  }
    //////////////////////////��Ӧ�Ҽ�������˵�///////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    void menuItem5_actionPerformed(ActionEvent e)
    {
        if(dateJudge(this.currentDateSubOne())==false)
      {
          return;
      }

        MakeWalkIn dlg = new MakeWalkIn();
        dlg.setLocation(400,300);
        dlg.SetControlDate(getStrCalendarDate());
        if(tip==1)
       {
           dlg.SetControlTno(tempTno);
           dlg.enableControlTno(false);
           if((this.getTableObjByTno(tempTno)).getBackground()==Color.green )
         {
             JOptionPane.showConfirmDialog(null,"����ѡ��ʱ���ѡ������Ѿ���ԤԼ������ִ��δԼ�Ͳͣ�","δԼ�Ͳ�ʧ�ܣ�",-1);
             return;
         }
         if((this.getTableObjByTno(tempTno)).getBackground()==Color.red )
         {
             JOptionPane.showConfirmDialog(null,"����ѡ��ʱ���ѡ������Ѿ����˾Ͳͣ�����δԼ�Ͳͣ�","δԼ�Ͳ�ʧ�ܣ�",-1);
             return;
         }
           tip = 0;
       }

        dlg.show();
        if(dlg.isConfirm == false)
        {
            return;
        }
        else
        {
            this.walkIn(5,this.getCalendarDate(),dlg.getTno());
            return;
        }
    }

    public void update(Observable arg0, Object arg1)
  {
      Vector vector1 = this.getstate();
      for(int i=0;i<=15;i++)
      {
          ((JLabel)vector.get(i)).setBackground(((Color)vector1.get(i)));
      }




  }
  /////////////////////////////////��ʼ��ʾԤԼ����////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////
  public void displayBooking(Date d)
  {
      bookingSystem.Display(d);
      //////////////////////////���õײ㺯��//////////////////////////////////////
  }
  ////////////////////////////////����ԤԼ����  ///////////////////////////////
    /////////////////////////////////////////////////////////////////////////
  public void makeReservation(Date d, int tno, String name, String phone)
  {
      bookingSystem.makeReservation(d,tno,name,phone);
      //////////////////�����²�///////////////////////
  }
  ////////////////////////////////ȡ��ԤԼ����////////////////////////////////
  //////////////////////////////////////////////////////////////////////////
  public void Cancel(Date date,int tno)
  {
      bookingSystem.cancel(date,tno);
       ///////////////////////�����²�/////////////////////////////////////
  }
  //////////////////////////////////ԤԼ���ﺯ��////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////
  public void recoreArrival(Date date,int tno)
  {
      bookingSystem.recordArrival(date,tno);
      //////////////////////////�����²㺯��/////////////////////////////////////
  }
  //////////////////////////////////������������/////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////
  public void transferTable(Date date,int originTable,int destTable)
  {
      bookingSystem.Transfer(date,originTable,destTable);
      //////////////////////////////�����²㺯��//////////////////////////////////
  }
  ///////////////////////////////////�û�δԤԼֱ�ӵ���//////////////////////////////
  //////////////////////////////////////////////////////////////////////////////
  public void walkIn(int guestNo,Date date,int tno)
  {
      bookingSystem.makeWalkln(guestNo,date,tno);
      ///////////////////////////////�����²㺯��//////////////////////////////
  }
///////////////////������Ӧ������¼�/////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////
    public void mouseClicked(MouseEvent e)
    {
        ////////////////���ú����滻///////////////////////////////////////////////////////
        dragFlag = 0;
        String strTable = ((JLabel)e.getSource()).getText().trim();
        tempTno=getTableTnoByText(strTable);
        int mods=e.getModifiers();
       //����Ҽ�
       if((mods&InputEvent.BUTTON3_MASK)!=0)
       {
            tip = 1;//�����˵�
            popupMenu1.show(this,e.getX()+220,e.getY()+140);
            tempTabelText = strTable;
       }
       int a  = e.getClickCount() ;
       if(e.getClickCount()==2)
    {
        //////////////////////////��ǰ����ΪδԤԼ״̬�������ܳ��ּ�¼����////////////////////////
        if(((JLabel)vector.get(tempTno-1)).getBackground()==Color.yellow  )
        {
              //JOptionPane.showConfirmDialog(null,"�ò�����û�б�ԤԼ���˿Ͳ����ܵ��","��������",-1);
              return;
        }
        //////////////////////////��ǰ�����Ѿ������òͣ������ܼ�¼����//////////////////////////////
        if(((JLabel)vector.get(tempTno-1)).getBackground()==Color.red)
        {
              //JOptionPane.showConfirmDialog(null,"�ò����ͻ������òͣ��˿Ͳ����ܵ��","��������",-1);
            return;
        }
        String message = Integer.toString(tempTno);
        message+="�Ų�������������ȷ����";
        if(JOptionPane.showConfirmDialog(null,message,"ѡ��",0)==0)
        {
            recoreArrival(this.getCalendarDate(),tempTno);
        }
        else
            return;
    }

    }
    ///////////////////����������Ӧ������¼�/////////////////////////////////////////////
  ////////////////////////////////////////////////////////////////////////////////
    public void frame_mouseClicked(MouseEvent e)
    {
        dragFlag = 0;
        tip = 0;
        int mods=e.getModifiers();
        //����Ҽ�
        if((mods&InputEvent.BUTTON3_MASK)!=0)
        {
            //�����˵�
             popupMenu1.show(this,e.getX(),e.getY());
        }
    }
    /////////////////////// �õ����ڿؼ�������Date��ʽ//////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    public Date getCalendarDate()
    {
        try {
            return date1.getSelectedDate();
        } catch (ParseException ex) {
            return null;
        }
    }
    //////////////////////////�õ����ڿؼ���String��ʽ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    public String getStrCalendarDate()
    {
        Date newDate = null;
        try {
            newDate = date1.getSelectedDate();
        } catch (ParseException ex) {
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = format.format(newDate);
        return strDate;
    }
///////////////////////������Ӧ�����ק�¼�//////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    public void dragTable(MouseEvent e){
        dragFlag = 1;
        tempDragFromText = ((JLabel)e.getSource()).getText().trim();
         if(getTableObjByTno(getTableTnoByText(tempDragFromText)).getBackground()==Color.red)
         {
              //JOptionPane.showConfirmDialog(null,"Դ�������ھͲͣ��������ܵ�����","��������",-1);
              return;

         }
         if(getTableObjByTno(getTableTnoByText(tempDragFromText)).getBackground()==Color.yellow )
         {
             //JOptionPane.showConfirmDialog(null,"Դ������û�б�ԤԼ���������ܵ�����","��������",-1);
              return;
         }
    }
    /////////////////////��Ӧ�����������¼�//////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    public void dragEnter(MouseEvent e){
     if(dragFlag ==1)
     {
         tempDragToText = ((JLabel) e.getSource()).getText().trim();
         everEnterFlag = 1;
         return;
     }
 }
 /////////////////////////////�û������������ڷſ�������Ӧ����//////////////////////
 /////////////////////////////////////////////////////////////////////////////////
    public void dragReleased(MouseEvent e) {
        if((dragFlag ==1)&(everEnterFlag == 1))
        {
            int tableTnoFrom = this.getTableTnoByText(tempDragFromText);
            int tableTnoTo = this.getTableTnoByText(tempDragToText);
            String intStrFrom = Integer.toString(tableTnoFrom);
            String intStrTo = Integer.toString(tableTnoTo);
            if(((JLabel)getTableObjByTno(tableTnoTo)).getBackground() == Color.red)
            {
                JOptionPane.showConfirmDialog(null,intStrTo+"�Ų����Ѿ����˾Ͳͣ��������ܵ�����","����������������",-1);
                return;
            }
            if(((JLabel)getTableObjByTno(tableTnoTo)).getBackground() == Color.green)
            {
                JOptionPane.showConfirmDialog(null,intStrTo+"�Ų����Ѿ�����Ԥ�����������ܵ�����","����������������",-1);
                return;
            }
            String message = intStrFrom +"�Ų���Ҫ��"+intStrTo+"�Ų���������ȷ����";
            if(JOptionPane.showConfirmDialog(null,message,"ѡ��",0)==0)
            {
                transferTable(this.getCalendarDate(),tableTnoFrom,tableTnoTo);
            }
            else
                return;
      }
        dragFlag = 0;
        tempDragFromText = "";
        tempDragToText = "";
        everEnterFlag = 0;
    }
////////////////////////////////�û��ڷ����������ڷſ����////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    public void isNotTableRelease(MouseEvent e) {
        dragFlag = 0;
        tempDragFromText = "";
        tempDragToText = "";
        everEnterFlag = 0;
    }
    public void popupMenu1_actionPerformed(ActionEvent e) {

    }
    public Vector getstate()
    {
        return bookingSystem.getTableState() ;
    }

//////////////////////////////�û������������ڰ���������Ӧ����///////////////////
    ////////////////////////////////////////////////////////////////////////////
    public void tableMousePressed(MouseEvent e) {
        everEnterFlag = 0;
    }

    public void displayDateBooking(ActionEvent e) {
        String m = this.getStrCalendarDate();
        Date d = this.getCalendarDate();
        bookingSystem.Display(this.getCalendarDate());
        int a = 5;
    }

    public void calendarMouseClicked(MouseEvent e) {
        //JOptionPane.showConfirmDialog(null,"�Ų����Ѿ�����Ԥ�����������ܵ�����","����������������",-1);

    }

    public void calendarConfirm(PopupMenuEvent e) {
        //JOptionPane.showConfirmDialog(null,"�Ų����Ѿ�����Ԥ�����������ܵ�����","����������������",-1);

    }

    public void contentPane_inputMethodTextChanged(InputMethodEvent event) {
       // JOptionPane.showConfirmDialog(null,"�Ų����Ѿ�����Ԥ�����������ܵ�����","����������������",-1);

    }
}


class booking_fr_date1_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_date1_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.calendarMouseClicked(e);
    }
}


class booking_fr_date1_popupMenuAdapter implements PopupMenuListener {
    private booking_fr adaptee;
    booking_fr_date1_popupMenuAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
    }

    public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
    }

    public void popupMenuCanceled(PopupMenuEvent e) {
        adaptee.calendarConfirm(e);
    }
}


class booking_fr_jButton8_actionAdapter implements ActionListener {
    private booking_fr adaptee;
    booking_fr_jButton8_actionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.displayDateBooking(e);
    }
}


class booking_fr_contentPane_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_contentPane_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}
class booking_fr_contentPane_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_contentPane_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.isNotTableRelease(e);
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.frame_mouseClicked(e);
    }

}


class booking_fr_contentPane_inputMethodAdapter implements InputMethodListener {
    private booking_fr adaptee;
    booking_fr_contentPane_inputMethodAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void inputMethodTextChanged(InputMethodEvent event) {
        adaptee.contentPane_inputMethodTextChanged(event);
    }

    public void caretPositionChanged(InputMethodEvent event) {
    }
}


/////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////

class booking_fr_table9_keyAdapter extends KeyAdapter {
    private booking_fr adaptee;
    booking_fr_table9_keyAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }
}
class booking_fr_jButton4_actionAdapter implements ActionListener {
    private booking_fr adaptee;
    booking_fr_jButton4_actionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
    }
}


class booking_fr_table9_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table9_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}
class booking_fr_table16_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table16_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }
    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}
class booking_fr_table15_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table15_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }
    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}
class booking_fr_table16_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table16_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }
    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}
class booking_fr_table15_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table15_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}

class booking_fr_table14_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table14_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }

}
class booking_fr_table10_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table10_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }

}
class booking_fr_table12_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table12_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {

        adaptee.dragTable(e);
    }
}

class booking_fr_table12_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table12_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}
class booking_fr_table13_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table13_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }

}


class booking_fr_table14_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table14_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table13_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table13_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table11_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table11_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }


}


class booking_fr_table11_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table11_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_this_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_this_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.frame_mouseClicked(e);
    }
}


class booking_fr_popupMenu1_actionAdapter implements ActionListener {
    private booking_fr adaptee;
    booking_fr_popupMenu1_actionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.popupMenu1_actionPerformed(e);
    }
}


class booking_fr_table9_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table9_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {

        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table10_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table10_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }

}

class booking_fr_table8_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table8_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table6_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table6_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table5_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table5_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table3_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table3_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table4_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table4_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}


class booking_fr_table2_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table2_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table2_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table2_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }


}


class booking_fr_table4_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_table4_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table6_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table6_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}


class booking_fr_table7_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table7_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}


class booking_fr_table8_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table8_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}


class booking_fr_table5_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table5_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}


class booking_fr_jLabel9_mouseAdapter extends MouseAdapter {
    private booking_fr adaptee;
    booking_fr_jLabel9_mouseAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.mouseClicked(e);
    }

    public void mouseReleased(MouseEvent e) {
        adaptee.dragReleased(e);
    }

    public void mouseEntered(MouseEvent e) {

        adaptee.dragEnter(e);
    }

    public void mousePressed(MouseEvent e) {
        adaptee.tableMousePressed(e);
    }
}


class booking_fr_table1_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table1_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }

}


class booking_fr_table3_mouseMotionAdapter extends MouseMotionAdapter {
    private booking_fr adaptee;
    booking_fr_table3_mouseMotionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseDragged(MouseEvent e) {
        adaptee.dragTable(e);
    }
}


class booking_fr_jMenuFileExit_ActionAdapter implements ActionListener {
    booking_fr adaptee;

    booking_fr_jMenuFileExit_ActionAdapter(booking_fr adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.jMenuFileExit_actionPerformed(actionEvent);
    }
}




