package newBookingSystem;

import java.util.Date;
import java.util.*;
import java.util.Observable;
import java.util.Vector;
import java.lang.*;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class BookingSystem extends Observable {
    private Date date;

    final static int NotSelected = 0;
    final static int Selected = 1;
    private static BookingSystem uniquelnstance;
    private Vector tableInformation;

    Restaurant restaurant;
    Booking booking;

    public BookingSystem() {
		restaurant = new Restaurant();
    }

    public static BookingSystem getlnstance() {
        if (uniquelnstance == null) {
            uniquelnstance = new BookingSystem();
        }
        return uniquelnstance;
    }

   /* public void addBooking(Booking b) {
        current.addElement(b);
    }
   */

    public void cancel(Date d, int tno) {
        java.sql.Date date = new java.sql.Date(d.getTime());
        restaurant.cancelReservation(date,tno);
        this.setChanged();
        this.notifyObservers();

    }


    public void Display(Date d) {
        restaurant.Display(d);
        this.setChanged();
        this.notifyObservers();
    }



    public Date getDate() {
        //return
        return date;

    }

    public void makeReservation(Date d, int tno, String name, String phone) {
		restaurant.makeReservation(d, tno, name, phone);
		this.setChanged();
        this.notifyObservers();
    }

    public void makeWalkln(int c, Date d, int tno) {
        restaurant.makeWalkIn(c, d, tno);
        this.setChanged();
        this.notifyObservers();
    }

    public void recordArrival(Date d,int tno) {
        restaurant.recordArrival(d,tno);
        this.setChanged();
        this.notifyObservers();
    }

    public void setDate(Date d) {
        date = d;
    }

    public void Transfer(Date d, int OriginTable, int destTable) {
		//OriginTable:ԭ����,destTable:Ŀ�Ĳ���
        restaurant.transfer(d, OriginTable, destTable);
        this.setChanged();
        this.notifyObservers();
    }

    public Vector getTableState()
    {
		tableInformation = restaurant.getState();
		return tableInformation;
	}


}
