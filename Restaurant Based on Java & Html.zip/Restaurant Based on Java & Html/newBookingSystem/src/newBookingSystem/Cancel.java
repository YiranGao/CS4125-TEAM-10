package newBookingSystem;

import java.awt.BorderLayout;
import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JLabel;
import com.borland.jbcl.layout.XYLayout;
import com.borland.jbcl.layout.*;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class Cancel extends JDialog {
    JPanel panel1 = new JPanel();
    BorderLayout borderLayout1 = new BorderLayout();
    XYLayout xYLayout1 = new XYLayout();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JLabel jLabel3 = new JLabel();
    JTextField ControlTno = new JTextField();
    JTextField ControlDate = new JTextField();
    JButton jButton1 = new JButton();
    JButton jButton2 = new JButton();

    /////////////////////�û������ȷ������ȡ���ı��ֵ//////////////////////////////////
  ////////////////////////////////////////////////////////////////////////
    public static boolean isConfirm;

    ///////////////////////�Ի����б���////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    private int tno;
    private String strDate;


    public Cancel(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    public int getTno()
     {
         return tno;
     }
     public String getStrDate()
     {
         return strDate;
  }


    public Cancel() {
        this(new Frame(), "Cancel", false);
    }
    ///////////////////////////���������� ��ʼֵ//////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    public void SetControlDate(String strDate)
    {
        ControlDate.setText(strDate);
    }
    ///////////////////////////����������//////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////////////

   public void enableControlTno(boolean tf)
   {
       ControlTno.setEditable(tf);

   }
   public void SetControlTno(int tno)
    {
        ControlTno.setText(Integer.toString(tno));

    }


    private void jbInit() throws Exception {
        panel1.setLayout(borderLayout1);
       // ControlTno.setDocument(new NumberLenghtLimitedDmt(2));
        this.getContentPane().setLayout(xYLayout1);
        this.setModal(true);
        this.setTitle("ȡ��ԤԼ");
        ControlDate.setEnabled(false);
        ControlDate.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlDate.setHorizontalAlignment(SwingConstants.CENTER);
        jButton1.addActionListener(new Cancel_jButton1_actionAdapter(this));
        jButton2.addActionListener(new Cancel_jButton2_actionAdapter(this));
        ControlTno.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTno.setHorizontalAlignment(SwingConstants.CENTER);
        this.getContentPane().add(panel1, new XYConstraints(0, 187, 305, -1));
        xYLayout1.setWidth(288);
        xYLayout1.setHeight(174);
        jButton2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton2.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton2.setText("ȡ��");
        jButton1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton1.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton1.setText("ȷ��");
        jLabel3.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel3.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel3.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel3.setText("����:");
        jLabel2.setText("jLabel2");
        jLabel1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel1.setToolTipText("");
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel1.setText("����:");
        this.getContentPane().add(jLabel2, new XYConstraints(78, 55, 18, 1));
        this.getContentPane().add(jButton1, new XYConstraints(50, 130, 78, -1));
        this.getContentPane().add(jButton2, new XYConstraints(167, 130, 79, 31));
        this.getContentPane().add(ControlDate,
                                  new XYConstraints(133, 78, 119, 32));
        this.getContentPane().add(ControlTno,
                                  new XYConstraints(133, 28, 119, 32));
        this.getContentPane().add(jLabel3, new XYConstraints(24, 78, 90, 32));
        this.getContentPane().add(jLabel1, new XYConstraints(23, 28, 90, 32));
    }
////////////////////////////�Ի���ȷ����ť��Ӧ�¼�//////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    public void jButton1_actionPerformed(ActionEvent e) {
        isConfirm = true;
       String strTno = ControlTno.getText().trim();
       tno = Integer.parseInt(strTno);
       strDate = ControlDate.getText().trim();
      this.dispose();
    }
//////////////////////////////��Ӧ�Ի����ϵ�ȡ����ť//////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    public void jButton2_actionPerformed(ActionEvent e) {
        isConfirm = false;
        this.dispose();
    }
}


class Cancel_jButton2_actionAdapter implements ActionListener {
    private Cancel adaptee;
    Cancel_jButton2_actionAdapter(Cancel adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton2_actionPerformed(e);
    }
}


class Cancel_jButton1_actionAdapter implements ActionListener {
    private Cancel adaptee;
    Cancel_jButton1_actionAdapter(Cancel adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton1_actionPerformed(e);
    }
}
