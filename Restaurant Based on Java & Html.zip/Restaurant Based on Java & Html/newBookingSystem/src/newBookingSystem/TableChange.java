package newBookingSystem;



import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JLabel;
import com.borland.jbcl.layout.XYLayout;
import com.borland.jbcl.layout.*;
import javax.swing.BorderFactory;
import java.awt.Color;
import javax.swing.*;
import java.awt.Font;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class TableChange extends JDialog {
    JPanel panel1 = new JPanel();
    BorderLayout borderLayout1 = new BorderLayout();
    XYLayout xYLayout1 = new XYLayout();
    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    JLabel jLabel3 = new JLabel();
    JTextField ControlTno = new JTextField();
    JTextField ControlDate = new JTextField();
    JButton jButton1 = new JButton();
    JButton jButton2 = new JButton();
    /////////////////////�û������ȷ������ȡ���ı��ֵ//////////////////////////////////
        ////////////////////////////////////////////////////////////////////////
    public static boolean isConfirm;

    ///////////////////////////////�������������ȡ�Ի������������ֵ///////////////
    //////////////////////////////////////////////////////////////////////////
    private int tno;
    private int tnoChange;
    private String strDate;
    JTextField ControlTnoChange = new JTextField();


    public TableChange(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public TableChange() {
        this(new Frame(), "TableChange", false);
    }
    ///////////////////////��ʼ���������е�ֵ////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    public void SetControlDate(String strDate)
   {
       ControlDate.setText(strDate);
   }
   ///////////////////////////����������//////////////////////////////////////////
   //////////////////////////////////////////////////////////////////////////////

   public void enableControlTno(boolean tf)
   {
       ControlTno.setEditable(tf);

   }
   public void SetControlTno(int tno)
  {
      ControlTno.setText(Integer.toString(tno));
  }



   public int getTno()
   {
       return tno;
   }
   public int getTnoChange()
   {
       return tnoChange;
   }
   public String getStrDate()
   {
       return strDate;
   }
    private void jbInit() throws Exception {
        //ControlTno.setDocument(new NumberLenghtLimitedDmt(2));
        //ControlTnoChange.setDocument(new NumberLenghtLimitedDmt(2));
        panel1.setLayout(borderLayout1);
        this.setModal(true);
        this.setTitle("��������");
        this.getContentPane().setLayout(xYLayout1);
        ControlDate.setEnabled(false);
        ControlDate.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlDate.setHorizontalAlignment(SwingConstants.CENTER);
        jButton1.addActionListener(new TableChange_jButton1_actionAdapter(this));
        jButton2.addActionListener(new TableChange_jButton2_actionAdapter(this));
        ControlTno.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTno.setHorizontalAlignment(SwingConstants.CENTER);
        ControlTnoChange.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTnoChange.setHorizontalAlignment(SwingConstants.CENTER);
        this.getContentPane().add(panel1, new XYConstraints(0, 238, 364, -1));
        jButton2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton2.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton2.setText("ȡ��");
        jButton1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton1.setHorizontalTextPosition(SwingConstants.CENTER);
        jButton1.setText("ȷ��");
        xYLayout1.setWidth(308);
        xYLayout1.setHeight(212);
        jLabel3.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel3.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel3.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel3.setText("����:");
        jLabel2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel2.setText("��������:");
        this.getContentPane().add(jLabel1, new XYConstraints(35, 27, -1, -1));
        jLabel1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel1.setText("ԭ������:");
        this.getContentPane().add(jLabel2, new XYConstraints(35, 68, -1, -1));
        this.getContentPane().add(jLabel3, new XYConstraints(34, 111, 93, -1));
        this.getContentPane().add(ControlTno,
                                  new XYConstraints(149, 26, 120, 27));
        this.getContentPane().add(ControlDate,
                                  new XYConstraints(148, 111, 121, 30));
        this.getContentPane().add(jButton1, new XYConstraints(68, 164, 74, 32));
        this.getContentPane().add(jButton2, new XYConstraints(178, 164, 74, 32));
        this.getContentPane().add(ControlTnoChange,
                                  new XYConstraints(148, 69, 121, 27));

    }
//////////////////////////��Ӧ�Ի����ϵ�ȷ����ť//////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    public void jButton1_actionPerformed(ActionEvent e) {
        isConfirm = true;

      String strTno = ControlTno.getText().trim();
      tno = Integer.parseInt(strTno);
      strDate = ControlDate.getText().trim();
      String strTnoChange = ControlTnoChange.getText().trim();
      tnoChange = Integer.parseInt(strTnoChange);
     this.dispose();
    }
/////////////////////////////�Ի���ȡ����ť��Ӧ�¼�/////////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    public void jButton2_actionPerformed(ActionEvent e) {
        isConfirm = false;
        this.dispose();
    }
}
class TableChange_jButton1_actionAdapter implements ActionListener {
    private TableChange adaptee;
    TableChange_jButton1_actionAdapter(TableChange adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton1_actionPerformed(e);
    }
}


class TableChange_jButton2_actionAdapter implements ActionListener {
    private TableChange adaptee;
    TableChange_jButton2_actionAdapter(TableChange adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton2_actionPerformed(e);
    }
}
