package newBookingSystem;

import java.util.Date;
import java.util.*;

public class WalkIn
    extends Booking {

  //WalkIn's constructor
  public WalkIn(int c, Date d, int t) {
    super(c, d, t);

  }

  //WalkIn about table's set and get method
  public void setTable(int t) {
    super.setTable(t);
  }

  public Table getTable() {
    return super.getTableInstance();
  }

  //WalkIn about covers's set and get method
  public void setCovers(int c) {
    super.setCovers(c);
  }

  public int getCovers() {
    return super.getCovers();
  }

  //WalkIn's about date's set and get method
  public void setDate(Date d) {
    super.setDate(d);
  }

  public Date getDate() {

    return super.getDate();
  }

}

