package newBookingSystem;
import java.util.*;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.util.Date;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JLabel;
import com.borland.jbcl.layout.XYLayout;
import com.borland.jbcl.layout.*;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JTextField;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public class AddReservation extends JDialog {


    JPanel panel1 = new JPanel();
    XYLayout xYLayout1 = new XYLayout();
    XYLayout xYLayout2 = new XYLayout();
    JLabel AddReservation = new JLabel();
    JLabel jLabel2 = new JLabel();
    JLabel jLabel3 = new JLabel();
    JTextField ControlName = new JTextField();
    JTextField ControlTel = new JTextField();
    JLabel jLabel1 = new JLabel();
    JTextField ControlDate = new JTextField();
    JButton jButton1 = new JButton();
    JButton jButton2 = new JButton();

    /////////////////////�û������ȷ������ȡ���ı��ֵ//////////////////////////////////
        ////////////////////////////////////////////////////////////////////////
    public static boolean isConfirm;

    ///////////////////////////////�������������ȡ�Ի������������ֵ///////////////
    //////////////////////////////////////////////////////////////////////////
    private String name;
    private int tno;
    private String strDate;
    private String tel;
    JTextField ControlTno = new JTextField();
    public AddReservation(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public AddReservation() {
        this(new Frame(), "AddReservation", false);
    }
    /////////////////////�����������е���ʾֵ//////////////////////////////
    //////////////////////////////////////////////////////////////////////
    public void SetControlDate(String strDate)
    {
        ControlDate.setText(strDate);
    }
    public void enableControlTno(boolean tf)
    {
        ControlTno.setEditable(tf);

    }
    ///////////////////////////��ʼ������//////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////

    public void SetControlTno(int tno)
    {
        ControlTno.setText(Integer.toString(tno));

    }

    private void jbInit() throws Exception {
       // ControlTel.setDocument(new NumberLenghtLimitedDmt(12));
       // ControlTno.setDocument(new NumberLenghtLimitedDmt(2));
        panel1.setLayout(xYLayout1);
        this.getContentPane().setLayout(xYLayout2);
        jLabel2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel2.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel3.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel3.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel3.setHorizontalTextPosition(SwingConstants.CENTER);
        xYLayout2.setWidth(331);
        xYLayout2.setHeight(228);
        this.setModal(true);
        this.setTitle("����ԤԼ");
        AddReservation.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        AddReservation.setHorizontalAlignment(SwingConstants.CENTER);
        AddReservation.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jLabel1.setBorder(BorderFactory.createLineBorder(Color.black));
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
        jLabel1.setText("����:");
        jButton1.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton1.setActionCommand("true");
        jButton1.setMnemonic('0');
        jButton1.setText("ȷ��");
        jButton1.addActionListener(new AddReservation_jButton1_actionAdapter(this));
        jButton1.addMouseListener(new AddReservation_jButton1_mouseAdapter(this));
        jButton2.setFont(new java.awt.Font("����", Font.PLAIN, 20));
        jButton2.setAction(null);
        jButton2.setActionCommand("false");
        jButton2.setText("ȡ��");
        jButton2.addActionListener(new AddReservation_jButton2_actionAdapter(this));
        ControlDate.setEnabled(false);
        ControlDate.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlDate.setHorizontalAlignment(SwingConstants.CENTER);
        ControlTno.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTno.setDisabledTextColor(Color.lightGray);
        ControlTno.setHorizontalAlignment(SwingConstants.CENTER);
        ControlName.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlName.setHorizontalAlignment(SwingConstants.CENTER);
        ControlTel.setFont(new java.awt.Font("����", Font.BOLD, 20));
        ControlTel.setHorizontalAlignment(SwingConstants.CENTER);
        ControlTel.addKeyListener(new AddReservation_ControlTel_keyAdapter(this));
        this.getContentPane().add(panel1, new XYConstraints(10, 10, 371, -1));
        this.getContentPane().add(jButton2, new XYConstraints(199, 187, 75, 33));

        this.getContentPane().add(jButton1, new XYConstraints(89, 188, 75, 33));
        this.getContentPane().add(ControlName,
                                  new XYConstraints(162, 17, 123, 29));
        this.getContentPane().add(ControlTno,
                                  new XYConstraints(162, 57, 123, 29));
        this.getContentPane().add(ControlTel,
                                  new XYConstraints(162, 103, 123, 29));
        this.getContentPane().add(AddReservation,
                                  new XYConstraints(45, 17, 87, 31));
        this.getContentPane().add(jLabel2, new XYConstraints(45, 57, 87, 31));
        this.getContentPane().add(jLabel3, new XYConstraints(46, 103, 87, 31));
        this.getContentPane().add(ControlDate,
                                  new XYConstraints(162, 146, 123, 29));
        this.getContentPane().add(jLabel1, new XYConstraints(45, 146, 87, 31));
        jLabel3.setText("�绰:");
        jLabel2.setText("����:");
        AddReservation.setBackground(Color.red);
        AddReservation.setBorder(BorderFactory.createLineBorder(Color.black));
        AddReservation.setText("����:");
    }

    public String getStrName()
    {
        return name;
    }
    public int getTno()
    {
        return tno;
    }
    public String GetTel()
    {
        return tel;
    }
    public String getStrDate()
    {
        return strDate;
    }
////////////////��Ӧ�Ի����ϵ�ȷ����ť//////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    public void jButton1_actionPerformed(ActionEvent e) {
        isConfirm = true;
        name = ControlName.getText().trim();
        String strTno = ControlTno.getText().trim();
       tno = Integer.parseInt(strTno);
       strDate = ControlDate.getText().trim();
       tel = ControlTel.getText().trim();
      this.dispose();
    }
///////////////////////��Ӧ�Ի����ϵ�ȡ����ť/////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    public void jButton2_actionPerformed(ActionEvent e) {
        isConfirm = false;
        this.dispose();
    }
}
class AddReservation_ControlTel_keyAdapter extends KeyAdapter {
    private AddReservation adaptee;
    AddReservation_ControlTel_keyAdapter(AddReservation adaptee) {
        this.adaptee = adaptee;
    }
}
class AddReservation_jButton1_mouseAdapter extends MouseAdapter {
    private AddReservation adaptee;
    AddReservation_jButton1_mouseAdapter(AddReservation adaptee) {
        this.adaptee = adaptee;
    }
}
class AddReservation_jButton1_actionAdapter implements ActionListener {
    private AddReservation adaptee;
    AddReservation_jButton1_actionAdapter(AddReservation adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jButton1_actionPerformed(e);
    }
}
class AddReservation_jButton2_actionAdapter implements ActionListener {
    private AddReservation adaptee;
    AddReservation_jButton2_actionAdapter(AddReservation adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jButton2_actionPerformed(e);
    }
}
