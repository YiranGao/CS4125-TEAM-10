package newBookingSystem;

public class Customer {

  //Customer's private properties
  private String name;
  private String phoneNumber;

  //Customer's constructor
  public Customer(String name, String tel) {
    this.name = name;
    this.phoneNumber = tel;
  }

  //Customer about name's set and get method
  public void setName(String Name) {
    name = Name;
  }

  public String getName() {
    return name;
  }

  //Customer about PhoneNumber's set and get method
  public void setPhoneNumber(String Tel) {
    phoneNumber = Tel;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

}

