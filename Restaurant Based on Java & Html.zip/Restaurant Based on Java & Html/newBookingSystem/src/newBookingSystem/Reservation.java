package newBookingSystem;

import java.util.Date;
import java.util.ArrayList;

public class Reservation
    extends Booking {

  //Reservation's private properties
  private Boolean isArrived;
  private Customer customer;

  //Reservation's constructor
  public Reservation(int c, Date d, int t, String name, String tel,
                     Boolean bool) {
    super(c, d, t);
    customer = new Customer(name, tel);
    isArrived = bool;
  }

  //Reservation about table's set and get method
  public void setTable(int t) {
    super.setTable(t);
  }

  public Table getTable() {
    return super.getTableInstance();
  }

  //Reservation about customer's set and get method
  public void setCustomer(String cName, String cTelephone) {
    customer = new Customer(cName, cTelephone);
  }

  public Customer getCutomerInstance() {
    return customer;
  }

  //Reservation about date's set and get method
  public void setDate(Date d) {
    super.setDate(d);
  }

  public Date getDate() {

    return super.getDate();
  }

  //Reservation about covers's set and get method
  public void setCovers(int c) {
    super.setCovers(c);
  }

  public int getCovers() {
    return super.getCovers();
  }

  //Reservation about isArrived's set and get method
  public void setIsArrived(Boolean flag) {
    this.isArrived = flag;
  }

  public boolean getIsArrived() {
    return isArrived;
  }

  //�ǵ����ݿ���ȥ��ͻ���Ϣ�أ����ǡ������д��ڽ��������
  public ArrayList getDetails() {
    ArrayList details = new ArrayList();

    details.add(customer.getName());
    details.add(customer.getPhoneNumber());
    return details;

  }

}
