package com.mhl.tools;
import java.awt.*;
public class ToolFont {

	
		public static Font f1 = new Font("����",Font.PLAIN,16);
		public static Font f2 = new Font("����",Font.PLAIN,14);
		public static Font f3 = new Font("����",Font.PLAIN,12);
	
}
