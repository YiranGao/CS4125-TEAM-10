This is two versions of booking system databases.
Both folders are exactly the same database structure.
The only different between them is self_contains file may not support in some mysql tools.
Seperate file working on every version of mysql.