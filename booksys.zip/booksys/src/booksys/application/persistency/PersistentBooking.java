
package booksys.application.persistency ;

import booksys.application.domain.* ;

interface PersistentBooking extends Booking
{
  int getId() ;
}
